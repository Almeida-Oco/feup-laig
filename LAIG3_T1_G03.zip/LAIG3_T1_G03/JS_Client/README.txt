LAIG Parser

Base code and demo scene provided by:
- Rui Pedro Peixoto Cardoso - up201305469@fe.up.pt
- Diogo da Silva Amaral - up201306082@fe.up.pt

Adapted by:
- Rui Rodrigues - rui.rodrigues@fe.up.pt

Completed by:

Class 1
Group 3
Elements:
 - Gonçalo Moreno - up201503871@fe.up.pt
 - João Almeida - up201505866@fe.up.pt
