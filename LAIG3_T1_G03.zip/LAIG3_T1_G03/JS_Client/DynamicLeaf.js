class DynamicLeaf extends GraphLeaf {
  constructor(scene, type, args) {
    super(scene, type, args);
  }
};
